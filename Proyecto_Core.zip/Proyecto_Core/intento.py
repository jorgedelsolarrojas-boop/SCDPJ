import pandas as pd
from faker import Faker
import random
from pathlib import Path

fake = Faker("es_ES")  # fallback si 'es_PE' no está disponible

input_path = Path("base sintetica.xlsx")   # coloca aquí tu archivo local
df_template = pd.read_excel(input_path)
columns = df_template.columns.tolist()

# heurísticas simplificadas para generar valores según nombre de columna
def gen_value(col, idx):
    name = col.lower()
    if name.startswith("n°") or name.strip() == "n°":
        return idx + 1
    if "dni" in name and "ruc" not in name:
        return str(fake.random_int(min=10000000, max=99999999))
    if "ruc" in name:
        return str(fake.random_int(min=10000000000, max=99999999999))
    if "correo" in name or "email" in name:
        if "institucional" in name:
            return fake.company_email()
        return fake.email()
    if "fecha" in name or "emisión" in name or "vencimiento" in name:
        return fake.date_between(start_date="-5y", end_date="+2y")
    if "tel" in name or "telefono" in name or "fono" in name:
        return fake.phone_number()
    if "dirección" in name or "direccion" in name:
        return fake.address().replace("\n", ", ")
    if "nombre" in name or "apellidos" in name or "suscriptor" in name:
        return fake.name()
    if "cargo" in name:
        return random.choice(["Analista", "Jefe", "Asistente", "Gerente"])
    if "estado" in name:
        return random.choice(["Activo", "Inactivo", "Pendiente", "Vigente"])
    # fallback: si la plantilla tiene valores, muestreamos uno; si no, palabra aleatoria
    sample_vals = df_template[col].dropna().unique().tolist()
    if sample_vals:
        return random.choice(sample_vals)
    return fake.word()

n = 200
rows = []
for i in range(n):
    row = {col: gen_value(col, i) for col in columns}
    rows.append(row)

df_synthetic = pd.DataFrame(rows, columns=columns)
df_synthetic.to_excel("datos_sinteticos_generados.xlsx", index=False)
df_synthetic.to_csv("datos_sinteticos_generados.csv", index=False, encoding="utf-8-sig")
print("Generado:", len(df_synthetic), "filas")
